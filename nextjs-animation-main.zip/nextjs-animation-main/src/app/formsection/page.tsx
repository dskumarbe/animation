import NavSection from "../NavSection";
import Registration from "./registration";


export default function ROICalculatorPage() {
  return (
    <>
      <NavSection />
      <hr className="mb-12 mt-12"></hr>
      <Registration />
    </>
  );
}